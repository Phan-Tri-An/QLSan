# 🎨 UI SPECIFICATIONS

> **Dự án**: [Tên dự án]  
> **Version**: 1.0  
> **Ngày tạo**: [YYYY-MM-DD]  
> **Design System**: [Tailwind / Bootstrap / Custom CSS]

---

## 1. 🎨 Design System

### 1.1 Color Palette

| Name | Hex | Usage |
|------|-----|-------|
| **Primary** | `#3B82F6` | Buttons, links, CTAs |
| **Primary Dark** | `#2563EB` | Hover states |
| **Primary Light** | `#DBEAFE` | Backgrounds |
| **Secondary** | `#6B7280` | Secondary text |
| **Success** | `#10B981` | Success messages |
| **Warning** | `#F59E0B` | Warnings |
| **Error** | `#EF4444` | Errors |
| **Background** | `#F9FAFB` | Page background |
| **Surface** | `#FFFFFF` | Cards, modals |
| **Text Primary** | `#111827` | Headings |
| **Text Secondary** | `#6B7280` | Body text |
| **Border** | `#E5E7EB` | Borders |

### 1.2 Typography

| Element | Font | Size | Weight | Line Height |
|---------|------|------|--------|-------------|
| H1 | Inter | 36px | 700 | 1.2 |
| H2 | Inter | 30px | 600 | 1.3 |
| H3 | Inter | 24px | 600 | 1.4 |
| H4 | Inter | 20px | 500 | 1.4 |
| Body | Inter | 16px | 400 | 1.6 |
| Small | Inter | 14px | 400 | 1.5 |
| Caption | Inter | 12px | 400 | 1.4 |

### 1.3 Spacing Scale

```
4px  (xs)  - Icon padding
8px  (sm)  - Small gaps
16px (md)  - Standard gap
24px (lg)  - Section padding
32px (xl)  - Large sections
48px (2xl) - Page margins
```

### 1.4 Breakpoints

| Name | Width | Target |
|------|-------|--------|
| `xs` | 0-479px | Mobile |
| `sm` | 480-767px | Large mobile |
| `md` | 768-1023px | Tablet |
| `lg` | 1024-1279px | Laptop |
| `xl` | 1280px+ | Desktop |

---

## 2. 🧩 Component Library

### 2.1 Button

```
┌─────────────────────────────────────┐
│  [Primary Button]                   │ <- Solid background
│  [Secondary Button]                 │ <- Outline
│  [Ghost Button]                     │ <- Text only
│  [Icon Button]                      │ <- Icon only
└─────────────────────────────────────┘
```

| Variant | Background | Text | Border | Hover |
|---------|------------|------|--------|-------|
| Primary | Primary | White | None | Primary Dark |
| Secondary | Transparent | Primary | Primary | Primary Light bg |
| Ghost | Transparent | Gray | None | Gray Light bg |
| Danger | Error | White | None | Error Dark |

**States**:
- Default, Hover, Active, Focus, Disabled, Loading

**Sizes**:
| Size | Height | Padding | Font Size |
|------|--------|---------|-----------|
| sm | 32px | 12px 16px | 14px |
| md | 40px | 12px 20px | 16px |
| lg | 48px | 16px 24px | 18px |

---

### 2.2 Input Field

```
┌─────────────────────────────────────┐
│ Label                               │
│ ┌─────────────────────────────────┐ │
│ │ [Icon] Placeholder text...      │ │
│ └─────────────────────────────────┘ │
│ Helper text or error message        │
└─────────────────────────────────────┘
```

| State | Border | Background | Label |
|-------|--------|------------|-------|
| Default | Gray | White | Gray |
| Focus | Primary | White | Primary |
| Error | Error | Error Light | Error |
| Disabled | Gray Light | Gray Light | Gray |

**Validation**:
```
Required: "Vui lòng nhập [field name]"
Email: "Email không hợp lệ"
Min length: "Tối thiểu [n] ký tự"
Max length: "Tối đa [n] ký tự"
Pattern: "Định dạng không hợp lệ"
```

---

### 2.3 Card

```
┌─────────────────────────────────────┐
│ ┌─────────────────────────────────┐ │
│ │    [Image / Media]              │ │
│ └─────────────────────────────────┘ │
│                                     │
│ Title                               │
│ Description text here...            │
│                                     │
│ [Action]            [Secondary]     │
└─────────────────────────────────────┘
```

| Property | Value |
|----------|-------|
| Border Radius | 8px |
| Shadow | 0 1px 3px rgba(0,0,0,0.1) |
| Hover Shadow | 0 4px 6px rgba(0,0,0,0.1) |
| Padding | 16px |

---

### 2.4 Modal / Dialog

```
┌─────────────────────────────────────────────────────────┐
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
│ ░░░░┌───────────────────────────────────────────┐░░░░░░ │
│ ░░░░│ Modal Title                          [X] │░░░░░░ │
│ ░░░░├───────────────────────────────────────────┤░░░░░░ │
│ ░░░░│                                           │░░░░░░ │
│ ░░░░│        Modal content goes here            │░░░░░░ │
│ ░░░░│                                           │░░░░░░ │
│ ░░░░├───────────────────────────────────────────┤░░░░░░ │
│ ░░░░│               [Cancel] [Confirm]          │░░░░░░ │
│ ░░░░└───────────────────────────────────────────┘░░░░░░ │
│ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ │
└─────────────────────────────────────────────────────────┘
       ↑ Overlay (rgba(0,0,0,0.5))
```

| Size | Width | Use Case |
|------|-------|----------|
| sm | 400px | Confirmations |
| md | 600px | Forms |
| lg | 800px | Complex content |
| full | 100% | Mobile |

---

### 2.5 Toast / Notification

```
┌──────────────────────────────────────┐
│ [✓] Success message here        [X] │ <- Green
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [!] Warning message here        [X] │ <- Yellow
└──────────────────────────────────────┘

┌──────────────────────────────────────┐
│ [✕] Error message here          [X] │ <- Red
└──────────────────────────────────────┘
```

| Property | Value |
|----------|-------|
| Position | Top-right |
| Duration | 3-5 seconds |
| Animation | Slide in from right |
| Max visible | 3 |

---

## 3. 📄 Page Layouts

### 3.1 Layout: Main (with Sidebar)

```
┌─────────────────────────────────────────────────────────────┐
│  🔵 Logo     [Search...          ]  [🔔] [🛒] [👤 User ▼]  │ Header
├────────┬────────────────────────────────────────────────────┤
│        │                                                    │
│  Nav   │                                                    │
│  ----  │                                                    │
│  Link1 │              MAIN CONTENT AREA                     │
│  Link2 │                                                    │
│  Link3 │              (Scrollable)                          │
│  ----  │                                                    │
│  Link4 │                                                    │
│        │                                                    │
├────────┴────────────────────────────────────────────────────┤
│  Footer: Copyright © 2026 | Links | Social                  │
└─────────────────────────────────────────────────────────────┘
```

**Measurements**:
| Element | Desktop | Mobile |
|---------|---------|--------|
| Header Height | 64px | 56px |
| Sidebar Width | 256px | Full (overlay) |
| Content Max Width | 1200px | 100% |
| Footer Height | 60px | auto |

---

### 3.2 Layout: Full Width (no Sidebar)

```
┌─────────────────────────────────────────────────────────────┐
│  🔵 Logo     [Search...          ]  [🔔] [🛒] [👤 User ▼]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                                                             │
│                    MAIN CONTENT AREA                        │
│                                                             │
│                    (Full width, centered)                   │
│                                                             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  Footer: Copyright © 2026 | Links | Social                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. 📱 Page Specifications

### 4.1 Page: Home

**URL**: `/`

**Layout**: Full Width

**Wireframe**:
```
┌─────────────────────────────────────────────────────────────┐
│  [Header]                                                   │
├─────────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────────┐  │
│  │              HERO BANNER / SLIDER                     │  │
│  │         "Welcome message / CTA"                       │  │
│  │              [Primary CTA Button]                     │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ═══════════════════════════════════════════════════════    │
│  🔥 Featured Products                          [View All]   │
│  ═══════════════════════════════════════════════════════    │
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐                           │
│  │Card1│ │Card2│ │Card3│ │Card4│  <- Horizontal scroll     │
│  └─────┘ └─────┘ └─────┘ └─────┘     on mobile             │
│                                                             │
│  ═══════════════════════════════════════════════════════    │
│  📁 Categories                                              │
│  ═══════════════════════════════════════════════════════    │
│  ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐                       │
│  │Cat│ │Cat│ │Cat│ │Cat│ │Cat│ │Cat│  <- Grid 2-6 cols    │
│  └───┘ └───┘ └───┘ └───┘ └───┘ └───┘                       │
│                                                             │
│  [Footer]                                                   │
└─────────────────────────────────────────────────────────────┘
```

**Elements**:

| Element | Component | Data | Actions |
|---------|-----------|------|---------|
| Hero Banner | Carousel | images[], title, cta | Navigate to link |
| Featured Products | ProductCard[] | products (limit 8) | Add to cart, View |
| Categories | CategoryCard[] | categories | Navigate |

---

### 4.2 Page: Product List

**URL**: `/products`, `/category/{slug}`

**Wireframe**:
```
┌─────────────────────────────────────────────────────────────┐
│  [Header]                                                   │
├─────────────────────────────────────────────────────────────┤
│  Breadcrumb: Home > Category > Subcategory                  │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │ Results: 125 products    [Sort: ▼] [Filters 🔽]    │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                             │
│  ┌────────┬──────────────────────────────────────────────┐  │
│  │FILTERS │                                              │  │
│  │        │  ┌────┐ ┌────┐ ┌────┐ ┌────┐               │  │
│  │Category│  │Prod│ │Prod│ │Prod│ │Prod│               │  │
│  │  □ A   │  │Card│ │Card│ │Card│ │Card│               │  │
│  │  □ B   │  └────┘ └────┘ └────┘ └────┘               │  │
│  │        │                                              │  │
│  │Price   │  ┌────┐ ┌────┐ ┌────┐ ┌────┐               │  │
│  │[_]-[_] │  │Prod│ │Prod│ │Prod│ │Prod│               │  │
│  │        │  │Card│ │Card│ │Card│ │Card│               │  │
│  │Rating  │  └────┘ └────┘ └────┘ └────┘               │  │
│  │  ★★★★★ │                                              │  │
│  │  ★★★★☆ │  ┌─────────────────────────────────────┐    │  │
│  │        │  │ [1] [2] [3] ... [10] [Next >]       │    │  │
│  └────────┴──└─────────────────────────────────────┘────┘  │
│                                                             │
│  [Footer]                                                   │
└─────────────────────────────────────────────────────────────┘
```

**Filter Panel (Mobile: Slide-in Drawer)**:
```
┌─────────────────────────────────────┐
│ Filters                        [X]  │
├─────────────────────────────────────┤
│ Category                            │
│   □ Electronics                     │
│   □ Fashion                         │
│   □ Home & Living                   │
├─────────────────────────────────────┤
│ Price Range                         │
│   [100,000] - [5,000,000] VND       │
├─────────────────────────────────────┤
│ Rating                              │
│   ○ 4★ & up                         │
│   ○ 3★ & up                         │
│   ○ 2★ & up                         │
├─────────────────────────────────────┤
│ [Reset]              [Apply (125)]  │
└─────────────────────────────────────┘
```

---

### 4.3 Page: Product Detail

**URL**: `/product/{slug}`

**Wireframe**:
```
┌─────────────────────────────────────────────────────────────┐
│  Breadcrumb: Home > Category > Product Name                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌────────────────────┐  ┌────────────────────────────────┐ │
│  │                    │  │ Product Name                   │ │
│  │   [Main Image]     │  │ ★★★★☆ (4.5) · 128 reviews     │ │
│  │                    │  │                                │ │
│  │                    │  │ ₫1,500,000  ₫2,000,000 (-25%) │ │
│  ├────────────────────┤  │                                │ │
│  │[img][img][img][img]│  │ ─────────────────────────────  │ │
│  └────────────────────┘  │ Variants:                      │ │
│                          │ [Black] [White] [Blue]         │ │
│                          │                                │ │
│                          │ Quantity: [-] [1] [+]          │ │
│                          │                                │ │
│                          │ [  🛒 Add to Cart  ]           │ │
│                          │ [  💳 Buy Now      ]           │ │
│                          │                                │ │
│                          │ 🚚 Free shipping > 500k        │ │
│                          │ ✓ 30-day returns               │ │
│                          └────────────────────────────────┘ │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ [Description] [Specifications] [Reviews (128)]       │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │ Tab content here...                                  │   │
│  │                                                      │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                             │
│  ═══════════════════════════════════════════════════════    │
│  Related Products                                           │
│  ┌────┐ ┌────┐ ┌────┐ ┌────┐                               │
│  │Card│ │Card│ │Card│ │Card│                               │
│  └────┘ └────┘ └────┘ └────┘                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Actions**:
| Action | Trigger | API Call | Result |
|--------|---------|----------|--------|
| Add to Cart | Click button | POST /api/cart | Toast success, Cart badge +1 |
| Buy Now | Click button | POST /api/cart → Navigate | Redirect to checkout |
| Change Quantity | +/- buttons | Local state | Update total price |
| Select Variant | Click variant | Local state | Update image, price |
| View Reviews | Click tab | GET /api/reviews | Load reviews |

---

### 4.4 Page: Checkout

**URL**: `/checkout`

**Wireframe**:
```
┌─────────────────────────────────────────────────────────────┐
│  CHECKOUT                                      Steps: 1/3   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌────────────────────────────┬───────────────────────────┐ │
│  │                            │                           │ │
│  │  1️⃣ SHIPPING INFORMATION   │  ORDER SUMMARY            │ │
│  │  ─────────────────────────  │  ───────────────────────  │ │
│  │                            │                           │ │
│  │  Full Name *               │  Product 1        ₫500k   │ │
│  │  [_____________________]   │  Product 2        ₫300k   │ │
│  │                            │  ─────────────────────    │ │
│  │  Phone *                   │  Subtotal:       ₫800k   │ │
│  │  [_____________________]   │  Shipping:        Free    │ │
│  │                            │  Discount:       -₫50k    │ │
│  │  Email *                   │  ═════════════════════    │ │
│  │  [_____________________]   │  TOTAL:          ₫750k   │ │
│  │                            │                           │ │
│  │  Address *                 │  ┌───────────────────────┐│ │
│  │  [_____________________]   │  │ Have a coupon?        ││ │
│  │                            │  │ [________] [Apply]    ││ │
│  │  City        District      │  └───────────────────────┘│ │
│  │  [▼_______] [▼________]    │                           │ │
│  │                            │                           │ │
│  │  Note (optional)           │                           │ │
│  │  [_____________________]   │                           │ │
│  │                            │                           │ │
│  │       [Continue to Payment →]                          │ │
│  │                            │                           │ │
│  └────────────────────────────┴───────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Validation Rules**:
| Field | Required | Validation | Error Message |
|-------|----------|------------|---------------|
| Full Name | Yes | Min 2 chars | Vui lòng nhập họ tên |
| Phone | Yes | Regex: ^0[0-9]{9,10}$ | Số điện thoại không hợp lệ |
| Email | Yes | Email format | Email không hợp lệ |
| Address | Yes | Min 10 chars | Vui lòng nhập địa chỉ đầy đủ |
| City | Yes | Select | Vui lòng chọn tỉnh/thành |
| District | Yes | Select | Vui lòng chọn quận/huyện |

---

## 5. 📲 Responsive Behavior

### 5.1 Navigation

| Breakpoint | Behavior |
|------------|----------|
| Desktop (≥1024px) | Full horizontal nav |
| Tablet (768-1023px) | Hamburger menu + Slide-in drawer |
| Mobile (<768px) | Hamburger menu + Full-screen overlay |

### 5.2 Product Grid

| Breakpoint | Columns | Card Width |
|------------|---------|------------|
| Desktop | 4 | 25% |
| Tablet | 3 | 33.33% |
| Mobile | 2 | 50% |

### 5.3 Forms

| Breakpoint | Layout |
|------------|--------|
| Desktop | 2 columns (label left, input right) |
| Mobile | 1 column (stacked) |

---

## 6. 🎬 Animations & Transitions

| Element | Animation | Duration | Easing |
|---------|-----------|----------|--------|
| Button hover | Background color | 150ms | ease-in-out |
| Card hover | translateY(-4px), shadow | 200ms | ease-out |
| Modal open | fade + scale | 200ms | ease-out |
| Modal close | fade + scale | 150ms | ease-in |
| Dropdown | slide down | 150ms | ease-out |
| Toast | slide in from right | 300ms | ease-out |
| Page transition | fade | 200ms | ease-in-out |

---

## 7. ♿ Accessibility

### 7.1 Requirements
- [ ] All images have alt text
- [ ] Color contrast ratio ≥ 4.5:1
- [ ] Focus states visible
- [ ] Keyboard navigable
- [ ] Screen reader labels (aria-label)
- [ ] Skip to main content link
- [ ] Form error announcements

### 7.2 Focus States
```css
:focus {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}
```

---

## 8. 🔗 Related Documents

- [PRD](prd.md)
- [User Stories](user-stories.md)
- [API Specs](api-specs.md)
- [Data Model](data-model.md)

---

> 📝 **Note**: Update document này khi có thay đổi UI design.
